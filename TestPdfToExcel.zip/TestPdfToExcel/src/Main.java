import com.aspose.pdf.Document;
import com.aspose.pdf.ExcelSaveOptions;

public class Main {
	
	public static void main(String[] args) {
		// Load PDF document
		String fileName="pdf";
		Document document = new Document(fileName+".pdf");
		// Instantiate ExcelSave Option object
		ExcelSaveOptions excelsave = new ExcelSaveOptions();
		// Save the output to XLS format
		document.save(fileName+".xls", excelsave);
		System.out.println("-----------done");
	}

}
